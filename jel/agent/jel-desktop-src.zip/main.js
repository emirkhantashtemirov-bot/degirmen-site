// Jel POS для Windows: окно кассы + встроенный помощник печати.
// Electron 22 - последняя версия, которая работает на Windows 7.
const { app, BrowserWindow, globalShortcut, shell } = require('electron');
const { spawn } = require('child_process');
const path = require('path');
const fs = require('fs');

const URL_POS = 'https://degirmen-navoi.kz/jel/';
let win = null;
let agent = null;

function startAgent() {
  const base = app.isPackaged ? path.join(process.resourcesPath, 'agent') : path.join(__dirname, 'agent');
  const script = path.join(base, 'jel-print.ps1');
  if (!fs.existsSync(script)) return;
  try {
    agent = spawn('powershell.exe', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-WindowStyle', 'Hidden', '-File', script], {
      windowsHide: true,
      stdio: 'ignore',
    });
    agent.on('exit', () => { agent = null; });
  } catch (e) {
    agent = null;
  }
}

function stopAgent() {
  if (agent) {
    try { agent.kill(); } catch (e) { /* уже остановлен */ }
    agent = null;
  }
}

function createWindow() {
  win = new BrowserWindow({
    width: 1280,
    height: 800,
    minWidth: 800,
    minHeight: 600,
    backgroundColor: '#121417',
    autoHideMenuBar: true,
    icon: path.join(__dirname, 'icon.ico'),
    title: 'Jel POS',
    webPreferences: { contextIsolation: true, nodeIntegration: false, sandbox: true, spellcheck: false },
  });
  win.setMenuBarVisibility(false);
  win.maximize();
  win.loadURL(URL_POS);
  // нет сети при первом запуске и кассы ещё нет в памяти - показать страницу ожидания
  win.webContents.on('did-fail-load', (e, code, desc, url, isMainFrame) => {
    if (isMainFrame) win.loadFile(path.join(__dirname, 'offline.html'));
  });
  // ссылки наружу открывать в обычном браузере
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (!url.startsWith(URL_POS)) shell.openExternal(url);
    return { action: url.startsWith(URL_POS) ? 'allow' : 'deny' };
  });
  win.on('closed', () => { win = null; });
}

if (!app.requestSingleInstanceLock()) {
  app.quit();
} else {
  app.on('second-instance', () => {
    if (win) {
      if (win.isMinimized()) win.restore();
      win.focus();
    }
  });
  app.whenReady().then(() => {
    startAgent();
    createWindow();
    globalShortcut.register('F11', () => { if (win) win.setFullScreen(!win.isFullScreen()); });
    globalShortcut.register('F5', () => { if (win) win.loadURL(URL_POS); });
  });
  app.on('window-all-closed', () => { app.quit(); });
  app.on('will-quit', () => {
    globalShortcut.unregisterAll();
    stopAgent();
  });
}
