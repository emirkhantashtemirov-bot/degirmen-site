﻿# Jel Print - помощник печати Jel POS.
# Работает на Windows 7, 8, 10, 11 без установки: нужен только встроенный PowerShell.
# Слушает http://localhost:17777 и отправляет сырые байты ESC/POS на принтер.
#   GET  /                      страница проверки
#   GET  /status                список принтеров
#   POST /print?printer=ИМЯ     тело запроса - байты для принтера
#   GET  /test?printer=ИМЯ      тестовый чек
# Имя принтера: как в "Устройства и принтеры", либо tcp:192.168.1.50:9100 для сетевого.
# Без параметра printer печать идёт на принтер по умолчанию.

$ErrorActionPreference = 'Stop'
$Port = 17777
$Version = '1.0'

$src = @"
using System;
using System.Runtime.InteropServices;
public class JelRaw {
  [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
  public class DOCINFO {
    [MarshalAs(UnmanagedType.LPWStr)] public string pDocName;
    [MarshalAs(UnmanagedType.LPWStr)] public string pOutputFile;
    [MarshalAs(UnmanagedType.LPWStr)] public string pDataType;
  }
  [DllImport("winspool.drv", EntryPoint = "OpenPrinterW", SetLastError = true, CharSet = CharSet.Unicode)]
  static extern bool OpenPrinter(string name, out IntPtr h, IntPtr def);
  [DllImport("winspool.drv", SetLastError = true)]
  static extern bool ClosePrinter(IntPtr h);
  [DllImport("winspool.drv", EntryPoint = "StartDocPrinterW", SetLastError = true, CharSet = CharSet.Unicode)]
  static extern int StartDocPrinter(IntPtr h, int level, [In] DOCINFO di);
  [DllImport("winspool.drv", SetLastError = true)]
  static extern bool EndDocPrinter(IntPtr h);
  [DllImport("winspool.drv", SetLastError = true)]
  static extern bool StartPagePrinter(IntPtr h);
  [DllImport("winspool.drv", SetLastError = true)]
  static extern bool EndPagePrinter(IntPtr h);
  [DllImport("winspool.drv", SetLastError = true)]
  static extern bool WritePrinter(IntPtr h, byte[] data, int count, out int written);

  public static void Send(string printer, byte[] data) {
    IntPtr h;
    if (!OpenPrinter(printer, out h, IntPtr.Zero))
      throw new Exception("принтер не открылся, код " + Marshal.GetLastWin32Error());
    try {
      DOCINFO di = new DOCINFO();
      di.pDocName = "Jel POS";
      di.pDataType = "RAW";
      if (StartDocPrinter(h, 1, di) == 0)
        throw new Exception("задание не создано, код " + Marshal.GetLastWin32Error());
      try {
        StartPagePrinter(h);
        int written;
        if (!WritePrinter(h, data, data.Length, out written))
          throw new Exception("запись не прошла, код " + Marshal.GetLastWin32Error());
        EndPagePrinter(h);
      } finally { EndDocPrinter(h); }
    } finally { ClosePrinter(h); }
  }
}
"@
Add-Type -TypeDefinition $src

function Get-Printers {
  $list = @()
  try {
    foreach ($p in (Get-WmiObject Win32_Printer)) {
      $list += New-Object PSObject -Property @{ Name = [string]$p.Name; Default = [bool]$p.Default }
    }
  } catch { }
  return ,$list
}

function Get-DefaultPrinter {
  foreach ($p in (Get-Printers)) { if ($p.Default) { return $p.Name } }
  return ''
}

function Get-Param([string]$query, [string]$name) {
  if (-not $query) { return '' }
  foreach ($pair in $query.TrimStart('?').Split('&')) {
    $kv = $pair.Split('=', 2)
    if ($kv.Length -eq 2 -and $kv[0] -eq $name) {
      return [Uri]::UnescapeDataString($kv[1].Replace('+', ' '))
    }
  }
  return ''
}

function Json-Str([string]$s) {
  return '"' + $s.Replace('\', '\\').Replace('"', '\"') + '"'
}

function Send-Bytes([string]$printer, [byte[]]$data) {
  if (-not $printer) { $printer = Get-DefaultPrinter }
  if (-not $printer) { throw 'не выбран принтер и нет принтера по умолчанию' }
  if ($printer.StartsWith('tcp:')) {
    $parts = $printer.Substring(4).Split(':')
    $port = 9100
    if ($parts.Length -gt 1) { $port = [int]$parts[1] }
    $client = New-Object System.Net.Sockets.TcpClient
    try {
      $client.SendTimeout = 5000
      $client.Connect($parts[0], $port)
      $stream = $client.GetStream()
      $stream.Write($data, 0, $data.Length)
      $stream.Flush()
    } finally { $client.Close() }
  } else {
    [JelRaw]::Send($printer, $data)
  }
  return $printer
}

function New-TestReceipt {
  $b = New-Object 'System.Collections.Generic.List[byte]'
  $ascii = [Text.Encoding]::ASCII
  $nl = [byte]10
  $b.AddRange([byte[]](27, 64))
  $b.AddRange([byte[]](27, 97, 1))
  $b.AddRange([byte[]](29, 33, 17))
  $b.AddRange([byte[]]$ascii.GetBytes('JEL POS')); $b.Add($nl)
  $b.AddRange([byte[]](29, 33, 0))
  $b.AddRange([byte[]]$ascii.GetBytes('test ' + (Get-Date -Format 'dd.MM.yyyy HH:mm:ss'))); $b.Add($nl)
  $b.AddRange([byte[]](27, 97, 0))
  $b.Add($nl)
  $sample = [string]'Привет, Донер! АБВГД абвгд ёЁ 1 500 тг'
  $tests = @(@(17, 866), @(46, 1251), @(59, 866), @(6, 866), @(7, 866))
  foreach ($t in $tests) {
    $b.AddRange([byte[]](27, 116, [byte]$t[0]))
    $b.AddRange([byte[]]$ascii.GetBytes('[' + $t[0] + '] '))
    $b.AddRange([byte[]][Text.Encoding]::GetEncoding([int]$t[1]).GetBytes($sample))
    $b.Add($nl)
  }
  $b.AddRange([byte[]](27, 116, 0))
  $b.Add($nl)
  $b.AddRange([byte[]]$ascii.GetBytes('123456789012345678901234567890123456789012345678')); $b.Add($nl)
  $b.AddRange([byte[]]$ascii.GetBytes('         1         2         3         4       48')); $b.Add($nl)
  $b.Add($nl); $b.Add($nl); $b.Add($nl); $b.Add($nl)
  $b.AddRange([byte[]](29, 86, 66, 0))
  return ,$b.ToArray()
}

function Get-HomePage {
  $rows = ''
  foreach ($p in (Get-Printers)) {
    $mark = ''
    if ($p.Default) { $mark = ' (по умолчанию)' }
    $href = '/test?printer=' + [Uri]::EscapeDataString($p.Name)
    $safe = $p.Name.Replace('&', '&amp;').Replace('<', '&lt;')
    $rows += '<p><b>' + $safe + '</b>' + $mark + ' - <a href="' + $href + '">напечатать тестовый чек</a></p>'
  }
  if (-not $rows) { $rows = '<p>Принтеры в Windows не найдены.</p>' }
  return '<!DOCTYPE html><html><head><meta charset="utf-8"><title>Jel Print</title>' +
    '<style>body{font-family:Segoe UI,Arial,sans-serif;background:#16181d;color:#eee;padding:24px;max-width:640px}a{color:#5fd0a0}</style></head><body>' +
    '<h2>Jel Print ' + $Version + ' работает</h2>' + $rows +
    '<p>На тестовом чеке будет несколько строк с номерами в скобках. Сфотографируйте чек: строка, где русский текст читается, показывает нужную настройку.</p>' +
    '</body></html>'
}

$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add('http://localhost:' + $Port + '/')
try {
  $listener.Start()
} catch {
  Write-Host ('Не удалось запустить Jel Print на порту ' + $Port + '. Возможно, он уже запущен.')
  Write-Host 'Если нет - запустите jel-print.bat правой кнопкой "От имени администратора".'
  Write-Host $_.Exception.Message
  Start-Sleep -Seconds 8
  exit 1
}
Write-Host ('Jel Print ' + $Version + ' работает: http://localhost:' + $Port + '/')
Write-Host 'Это окно можно свернуть. Закрытие окна остановит печать.'

$utf8 = New-Object System.Text.UTF8Encoding($false)
while ($listener.IsListening) {
  $ctx = $listener.GetContext()
  $req = $ctx.Request
  $res = $ctx.Response
  $status = 200
  $type = 'application/json; charset=utf-8'
  $body = '{"ok":true}'
  try {
    $res.Headers.Add('Access-Control-Allow-Origin', '*')
    $res.Headers.Add('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
    $res.Headers.Add('Access-Control-Allow-Headers', 'Content-Type')
    $res.Headers.Add('Access-Control-Allow-Private-Network', 'true')
    $res.Headers.Add('Cache-Control', 'no-store')
    $path = $req.Url.AbsolutePath
    $query = $req.Url.Query
    if ($req.HttpMethod -eq 'OPTIONS') {
      $status = 204
      $body = ''
    } elseif ($path -eq '/status') {
      $names = @()
      foreach ($p in (Get-Printers)) { $names += (Json-Str $p.Name) }
      $body = '{"ok":true,"version":' + (Json-Str $Version) + ',"default":' + (Json-Str (Get-DefaultPrinter)) +
        ',"printers":[' + ($names -join ',') + ']}'
    } elseif ($path -eq '/print' -and $req.HttpMethod -eq 'POST') {
      $ms = New-Object System.IO.MemoryStream
      $buf = New-Object byte[] 8192
      while (($n = $req.InputStream.Read($buf, 0, $buf.Length)) -gt 0) { $ms.Write($buf, 0, $n) }
      $data = $ms.ToArray()
      if ($data.Length -eq 0) { throw 'пустое задание' }
      $used = Send-Bytes (Get-Param $query 'printer') $data
      Write-Host ((Get-Date -Format 'HH:mm:ss') + ' печать ' + $data.Length + ' байт -> ' + $used)
      $body = '{"ok":true,"printer":' + (Json-Str $used) + ',"bytes":' + $data.Length + '}'
    } elseif ($path -eq '/test') {
      $used = Send-Bytes (Get-Param $query 'printer') (New-TestReceipt)
      Write-Host ((Get-Date -Format 'HH:mm:ss') + ' тестовый чек -> ' + $used)
      $type = 'text/html; charset=utf-8'
      $body = '<!DOCTYPE html><html><head><meta charset="utf-8"></head><body style="font-family:sans-serif;background:#16181d;color:#eee;padding:24px">' +
        '<h2>Тестовый чек отправлен</h2><p><a style="color:#5fd0a0" href="/">Назад</a></p></body></html>'
    } elseif ($path -eq '/') {
      $type = 'text/html; charset=utf-8'
      $body = Get-HomePage
    } else {
      $status = 404
      $body = '{"ok":false,"error":"not found"}'
    }
  } catch {
    $status = 500
    $type = 'application/json; charset=utf-8'
    $body = '{"ok":false,"error":' + (Json-Str ([string]$_.Exception.Message)) + '}'
    Write-Host ((Get-Date -Format 'HH:mm:ss') + ' ошибка: ' + $_.Exception.Message)
  }
  try {
    $res.StatusCode = $status
    $bytes = $utf8.GetBytes($body)
    if ($bytes.Length -gt 0) {
      $res.ContentType = $type
      $res.ContentLength64 = $bytes.Length
      $res.OutputStream.Write($bytes, 0, $bytes.Length)
    }
    $res.Close()
  } catch { }
}
