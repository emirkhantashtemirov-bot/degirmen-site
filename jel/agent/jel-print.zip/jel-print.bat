@echo off
title Jel Print
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0jel-print.ps1"
if errorlevel 1 pause
