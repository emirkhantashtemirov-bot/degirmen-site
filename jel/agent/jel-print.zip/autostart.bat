@echo off
rem Adds Jel Print to Windows startup for the current user
echo start "" /min "%~dp0jel-print.bat" > "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\jel-print-start.bat"
echo Done. Jel Print will start with Windows.
pause
